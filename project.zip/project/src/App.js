import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import AttendanceList from './components/AttendanceList';
import CheckInOut from './components/CheckInOut';
import SearchBar from './components/SearchBar';

const API_URL = 'http://localhost:3000/attendance';

function App() {
  const [attendance, setAttendance] = useState([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetch(API_URL)
      .then((res) => res.json())
      .then((data) => setAttendance(data))
      .catch(console.error);
  }, []);

  // Add new check-in/out record
  const addRecord = (record) => {
    setAttendance((prev) => [...prev, record]);
    // POST to server (mock example, no backend)
    fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(record)
    }).catch(console.error);
  };

  // Filtered list based on search
  const filteredAttendance = attendance.filter((rec) =>
    rec.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="container mt-5">
      <h1 className="mb-4">Employee Attendance Tracker</h1>
      <CheckInOut addRecord={addRecord} />
      <SearchBar search={search} setSearch={setSearch} />
      <AttendanceList attendance={filteredAttendance} />
    </div>
  );
}

export default App;