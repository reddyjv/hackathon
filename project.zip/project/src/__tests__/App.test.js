import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import App from '../App';

global.fetch = jest.fn(() =>
  Promise.resolve({
    json: () =>
      Promise.resolve([
        { id: 1, name: 'Alice', action: 'checkin', time: '2025-05-31 09:00' },
        { id: 2, name: 'Bob', action: 'checkout', time: '2025-05-31 17:00' }
      ]),
  })
);

describe('Employee Attendance Tracker App', () => {
  beforeEach(() => {
    fetch.mockClear();
  });

  test('renders main heading', async () => {
    render(<App />);
    expect(screen.getByText(/employee attendance tracker/i)).toBeInTheDocument();
    await waitFor(() => expect(fetch).toHaveBeenCalledTimes(1));
  });

  test('displays fetched attendance records', async () => {
    render(<App />);
    const rows = await screen.findAllByTestId('attendance-record');
    expect(rows.length).toBe(2);
    expect(screen.getByText('Alice')).toBeInTheDocument();
    expect(screen.getByText('Bob')).toBeInTheDocument();
  });

  test('allows user to add check-in record', async () => {
    render(<App />);
    const input = screen.getByTestId('input-name');
    const select = screen.getByTestId('select-action');
    const button = screen.getByTestId('btn-submit');

    fireEvent.change(input, { target: { value: 'Charlie' } });
    fireEvent.change(select, { target: { value: 'checkin' } });
    fireEvent.click(button);

    const newRecord = await screen.findByText('Charlie');
    expect(newRecord).toBeInTheDocument();
  });

  test('search filters attendance records', async () => {
    render(<App />);
    await screen.findAllByTestId('attendance-record');

    const searchInput = screen.getByTestId('input-search');
    fireEvent.change(searchInput, { target: { value: 'alice' } });

    expect(screen.getByText('Alice')).toBeInTheDocument();
    expect(screen.queryByText('Bob')).toBeNull();
  });

  test('does not allow submitting empty name', () => {
    render(<App />);
    const button = screen.getByTestId('btn-submit');
    window.alert = jest.fn();
    fireEvent.click(button);
    expect(window.alert).toHaveBeenCalledWith('Please enter a name');
  });
});