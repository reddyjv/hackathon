import React, { useState } from 'react';

function CheckInOut({ addRecord }) {
  const [name, setName] = useState('');
  const [action, setAction] = useState('checkin');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name.trim()) return alert('Please enter a name');
    const record = {
      id: Date.now(),
      name: name.trim(),
      action,
      time: new Date().toLocaleString()
    };
    addRecord(record);
    setName('');
  };

  return (
    <form onSubmit={handleSubmit} className="mb-4">
      <div className="row g-2 align-items-center">
        <div className="col-auto">
          <input
            type="text"
            className="form-control"
            placeholder="Employee Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            data-testid="input-name"
          />
        </div>
        <div className="col-auto">
          <select
            className="form-select"
            value={action}
            onChange={(e) => setAction(e.target.value)}
            data-testid="select-action"
          >
            <option value="checkin">Check In</option>
            <option value="checkout">Check Out</option>
          </select>
        </div>
        <div className="col-auto">
          <button type="submit" className="btn btn-primary" data-testid="btn-submit">
            Submit
          </button>
        </div>
      </div>
    </form>
  );
}

export default CheckInOut;