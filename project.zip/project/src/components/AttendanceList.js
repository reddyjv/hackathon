import React from 'react';

function AttendanceList({ attendance }) {
  if (attendance.length === 0) return <p>No attendance records found.</p>;

  return (
    <table className="table table-striped" data-testid="attendance-table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Action</th>
          <th>Time</th>
        </tr>
      </thead>
      <tbody>
        {attendance.map((record) => (
          <tr key={record.id} data-testid="attendance-record">
            <td>{record.name}</td>
            <td>{record.action}</td>
            <td>{record.time}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default AttendanceList;