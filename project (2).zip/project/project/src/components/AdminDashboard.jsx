import React, { useEffect, useState } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

const AdminDashboard = () => {
  const [employees, setEmployees] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dateFilter, setDateFilter] = useState('');

  useEffect(() => {
    axios.get('http://localhost:3001/attendance')
      .then((response) => setEmployees(response.data))
      .catch((error) => console.error('Error fetching data:', error));
  }, []);

  const formatTime = (isoString) => {
    if (!isoString) return 'N/A';
    const date = new Date(isoString);
    return date.toLocaleTimeString();
  };

  const calculateWorkingHours = (checkIn, checkOut) => {
    if (!checkIn || !checkOut) return 'N/A';
    const start = new Date(checkIn);
    const end = new Date(checkOut);
    const diffMs = end - start;
    if (diffMs < 0) return 'N/A';
    const hours = Math.floor(diffMs / 3600000);
    const minutes = Math.floor((diffMs % 3600000) / 60000);
    return `${hours} hours ${minutes} minutes`;
  };

  const filteredEmployees = employees.filter((emp) => {
    const matchesSearch = emp.employeeId?.includes(searchTerm);
    const matchesStatus = statusFilter === 'all' || emp.status === statusFilter;
    const matchesDate = dateFilter === '' || emp.date === dateFilter;
    return matchesSearch && matchesStatus && matchesDate;
  });

  const getStatusCount = (status) => 
    employees.filter((emp) => emp.status === status).length;

  const total = employees.length || 1;
  const presentCount = getStatusCount('present');
  const absentCount = getStatusCount('absent');
  const leaveCount = getStatusCount('leave');

  const statusPercentage = (count) => Math.round((count / total) * 100);

  return (
    <div className="container my-5">
      <h2 className="mb-4 text-center text-primary">Admin Dashboard</h2>

      {/* Summary Cards */}
      <div className="row text-center mb-4">
        <div className="col-md-4 mb-2">
          <div className="card border-success shadow-sm">
            <div className="card-body">
              <h5 className="card-title text-success">Present</h5>
              <h3>{presentCount}</h3>
              <div className="progress">
                <div className="progress-bar bg-success" style={{ width: `${statusPercentage(presentCount)}%` }}>
                  {statusPercentage(presentCount)}%
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-4 mb-2">
          <div className="card border-danger shadow-sm">
            <div className="card-body">
              <h5 className="card-title text-danger">Absent</h5>
              <h3>{absentCount}</h3>
              <div className="progress">
                <div className="progress-bar bg-danger" style={{ width: `${statusPercentage(absentCount)}%` }}>
                  {statusPercentage(absentCount)}%
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-4 mb-2">
          <div className="card border-warning shadow-sm">
            <div className="card-body">
              <h5 className="card-title text-warning">Leave</h5>
              <h3>{leaveCount}</h3>
              <div className="progress">
                <div className="progress-bar bg-warning" style={{ width: `${statusPercentage(leaveCount)}%` }}>
                  {statusPercentage(leaveCount)}%
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="row mb-4">
        <div className="col-md-4 mb-2">
          <input
            type="text"
            className="form-control"
            placeholder="Search by Employee ID"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="col-md-4 mb-2">
          <select
            className="form-select"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="all">All Statuses</option>
            <option value="present">Present</option>
            <option value="absent">Absent</option>
            <option value="leave">Leave</option>
          </select>
        </div>
        <div className="col-md-4 mb-2">
          <input
            type="date"
            className="form-control"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
          />
        </div>
      </div>

      {/* Data Table */}
      <div className="table-responsive">
        <table className="table table-bordered table-hover shadow-sm">
          <thead className="table-dark text-center">
            <tr>
              <th>Employee ID</th>
              <th>Date</th>
              <th>Status</th>
              <th>Check-In</th>
              <th>Check-Out</th>
              <th>Working Hours</th>
            </tr>
          </thead>
          <tbody className="text-center">
            {filteredEmployees.map((emp) => (
              <tr key={emp.id}>
                <td>{emp.employeeId}</td>
                <td>{emp.date}</td>
                <td>
                  <span className={`badge bg-${
                    emp.status === 'present' ? 'success' :
                    emp.status === 'absent' ? 'danger' : 'warning'
                  }`}>
                    {emp.status}
                  </span>
                </td>
                <td>{formatTime(emp.checkIn)}</td>
                <td>{formatTime(emp.checkOut)}</td>
                <td>{emp.workingHours || calculateWorkingHours(emp.checkIn, emp.checkOut)}</td>
              </tr>
            ))}
            {filteredEmployees.length === 0 && (
              <tr>
                <td colSpan="6" className="text-muted">No matching records found.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminDashboard;
