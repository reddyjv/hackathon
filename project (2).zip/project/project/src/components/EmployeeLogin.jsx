import React, { useState } from 'react';
import axios from 'axios';
import { FaUser, FaLock, FaSpinner, FaSignInAlt } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';
import './EmployeeLogin.css';

const EmployeeLogin = () => {
  const [loginData, setLoginData] = useState({
    employeeId: '',
    password: ''
  });

  const [rememberMe, setRememberMe] = useState(false);
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [loginError, setLoginError] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setLoginData(prev => ({
      ...prev,
      [name]: value
    }));

    // Clear errors when typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
    if (loginError) setLoginError('');
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!loginData.employeeId.trim()) {
      newErrors.employeeId = 'Employee ID is required';
    }
    if (!loginData.password) {
      newErrors.password = 'Password is required';
    } else if (loginData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsLoading(true);
    setLoginError('');
    
    try {
      // Check if employee exists in db.json
      const response = await axios.get(`http://localhost:3001/employees?employeeId=${loginData.employeeId}`);
      
      if (response.data.length === 0) {
        throw new Error('Employee not found');
      }
      
      const employee = response.data[0];
      
      // Simple password comparison (in real app, you'd compare hashed passwords)
      if (employee.password !== loginData.password) {
        throw new Error('Invalid credentials');
      }
      
      // Store login state (in real app, use proper auth tokens)
      if (rememberMe) {
        localStorage.setItem('employee', JSON.stringify(employee));
      } else {
        sessionStorage.setItem('employee', JSON.stringify(employee));
      }
      
      // Redirect to dashboard or home page
      navigate('/dashboard');
      
    } catch (error) {
      console.error('Login failed:', error);
      setLoginError(error.message || 'Login failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <div className="login-header">
          <div className="logo">
            <FaSignInAlt />
          </div>
          <h2>Employee Login</h2>
          <p>Track your attendance and working hours</p>
        </div>
        
        {loginError && (
          <div className="error-message">
            {loginError}
          </div>
        )}
        
        <form onSubmit={handleSubmit}>
          <div className={`form-group ${errors.employeeId ? 'error' : ''}`}>
            <label htmlFor="employeeId">
              <FaUser className="input-icon" /> Employee ID
            </label>
            <input
              type="text"
              id="employeeId"
              name="employeeId"
              value={loginData.employeeId}
              onChange={handleChange}
              placeholder="Enter your employee ID"
            />
            {errors.employeeId && <span className="error-text">{errors.employeeId}</span>}
          </div>
          
          <div className={`form-group ${errors.password ? 'error' : ''}`}>
            <label htmlFor="password">
              <FaLock className="input-icon" /> Password
            </label>
            <input
              type="password"
              id="password"
              name="password"
              value={loginData.password}
              onChange={handleChange}
              placeholder="Enter your password"
            />
            {errors.password && <span className="error-text">{errors.password}</span>}
          </div>
          
          <div className="form-options">
            <div className="remember-me">
              <input 
                type="checkbox" 
                id="remember" 
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
              />
              <label htmlFor="remember">Remember me</label>
            </div>
            <a href="#forgot" className="forgot-password">Forgot password?</a>
          </div>
          
          <button 
            type="submit" 
            className="login-btn"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <FaSpinner className="spin" /> Logging in...
              </>
            ) : (
              'Login'
            )}
          </button>
        </form>
        
        <div className="login-footer">
          <p>Don't have an account? <a href="/register">Register here</a></p>
        </div>
      </div>
    </div>
  );
};

export default EmployeeLogin;