import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { FaUser, FaCalendarAlt, FaClock, FaSignOutAlt, FaChartPie, FaHistory } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';
import './EmployeeDashboard.css';

const EmployeeDashboard = () => {
  const [employee, setEmployee] = useState(null);
  const [attendance, setAttendance] = useState([]);
  const [todayAttendance, setTodayAttendance] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  // Calculate attendance percentage
  const calculatePercentage = () => {
    if (!attendance.length) return 0;
    const presentDays = attendance.filter(entry => entry.status === 'present').length;
    return Math.round((presentDays / attendance.length) * 100);
  };

  // Check if check-out is available (only if checked in today and not checked out)
  const canCheckOut = () => {
    if (!todayAttendance) return false;
    return todayAttendance.checkIn && !todayAttendance.checkOut;
  };

  // Check if check-in is available (only if not checked in today)
  const canCheckIn = () => {
    return !todayAttendance || !todayAttendance.checkIn;
  };

  // Format time
  const formatTime = (timeString) => {
    if (!timeString) return '--:--';
    const time = new Date(timeString);
    return time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // Format date
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  // Handle check-in
  const handleCheckIn = async () => {
    try {
      setIsLoading(true);
      const now = new Date().toISOString();
      
      // If no attendance record exists for today, create one
      if (!todayAttendance) {
        const newAttendance = {
          employeeId: employee.employeeId,
          date: new Date().toISOString().split('T')[0],
          checkIn: now,
          status: 'present'
        };
        
        const response = await axios.post('http://localhost:3001/attendance', newAttendance);
        setTodayAttendance(response.data);
        setAttendance([...attendance, response.data]);
      } else {
        // Update existing record
        const updatedAttendance = {
          ...todayAttendance,
          checkIn: now,
          status: 'present'
        };
        
        const response = await axios.put(
          `http://localhost:3001/attendance/${todayAttendance.id}`,
          updatedAttendance
        );
        
        setTodayAttendance(response.data);
        setAttendance(attendance.map(a => 
          a.id === todayAttendance.id ? response.data : a
        ));
      }
      
    } catch (error) {
      console.error('Check-in failed:', error);
      setError('Failed to check in. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // Handle check-out
  const handleCheckOut = async () => {
    try {
      setIsLoading(true);
      const now = new Date().toISOString();
      
      const updatedAttendance = {
        ...todayAttendance,
        checkOut: now,
        workingHours: calculateWorkingHours(todayAttendance.checkIn, now)
      };
      
      const response = await axios.put(
        `http://localhost:3001/attendance/${todayAttendance.id}`,
        updatedAttendance
      );
      
      setTodayAttendance(response.data);
      setAttendance(attendance.map(a => 
        a.id === todayAttendance.id ? response.data : a
      ));
      
    } catch (error) {
      console.error('Check-out failed:', error);
      setError('Failed to check out. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // Calculate working hours
  const calculateWorkingHours = (checkIn, checkOut) => {
    if (!checkIn || !checkOut) return '0 hours';
    
    const start = new Date(checkIn);
    const end = new Date(checkOut);
    const diffMs = end - start;
    
    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    
    return `${hours} hours ${minutes} minutes`;
  };

  // Handle logout
  const handleLogout = () => {
    localStorage.removeItem('employee');
    sessionStorage.removeItem('employee');
    navigate('/login');
  };

  // Fetch employee data and attendance
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Get employee from storage
        const storedEmployee = JSON.parse(localStorage.getItem('employee') || sessionStorage.getItem('employee'));
        if (!storedEmployee) {
          navigate('/login');
          return;
        }
        
        setEmployee(storedEmployee);
        
        // Get attendance records
        const today = new Date().toISOString().split('T')[0];
        
        const attendanceRes = await axios.get(
          `http://localhost:3001/attendance?employeeId=${storedEmployee.employeeId}&_sort=date&_order=desc`
        );
        
        setAttendance(attendanceRes.data);
        
        // Find today's attendance
        const todayRecord = attendanceRes.data.find(
          record => record.date === today
        );
        
        setTodayAttendance(todayRecord || null);
        
      } catch (error) {
        console.error('Failed to fetch data:', error);
        setError('Failed to load dashboard data.');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, [navigate]);

  if (isLoading) {
    return (
      <div className="dashboard-loading">
        <div className="spinner"></div>
        <p>Loading your dashboard...</p>
      </div>
    );
  }

  if (!employee) {
    return (
      <div className="dashboard-error">
        <p>No employee data found. Please login again.</p>
        <button onClick={() => navigate('/login')}>Go to Login</button>
      </div>
    );
  }

  return (
    <div className="dashboard-container">
      {/* Sidebar */}
      <div className="dashboard-sidebar">
        <div className="sidebar-header">
          <div className="employee-avatar">
            {employee.name.charAt(0).toUpperCase()}
          </div>
          <h3>{employee.name}</h3>
          <p>{employee.position}</p>
        </div>
        
        <div className="sidebar-stats">
          <div className="stat-item">
            <FaChartPie className="stat-icon" />
            <div>
              <span className="stat-value">{calculatePercentage()}%</span>
              <span className="stat-label">Attendance</span>
            </div>
          </div>
        </div>
        
        <nav className="sidebar-nav">
          <button className="nav-button active">
            <FaCalendarAlt /> Today
          </button>
          <button className="nav-button">
            <FaHistory /> History
          </button>
        </nav>
        
        <button className="logout-button" onClick={handleLogout}>
          <FaSignOutAlt /> Logout
        </button>
      </div>
      
      {/* Main Content */}
      <div className="dashboard-main">
        <div className="dashboard-header">
          <h1>Employee Dashboard</h1>
          <p>{formatDate(new Date())}</p>
        </div>
        
        {error && (
          <div className="dashboard-error-message">
            {error}
          </div>
        )}
        
        {/* Attendance Card */}
        <div className="attendance-card">
          <div className="attendance-header">
            <h2>Today's Attendance</h2>
            <div className="attendance-status">
              {todayAttendance?.status === 'present' ? (
                <span className="status-present">Present</span>
              ) : (
                <span className="status-absent">Not Checked In</span>
              )}
            </div>
          </div>
          
          <div className="attendance-times">
            <div className="time-card">
              <FaClock className="time-icon" />
              <div>
                <span className="time-label">Check In</span>
                <span className="time-value">
                  {todayAttendance?.checkIn ? formatTime(todayAttendance.checkIn) : '--:--'}
                </span>
              </div>
            </div>
            
            <div className="time-card">
              <FaClock className="time-icon" />
              <div>
                <span className="time-label">Check Out</span>
                <span className="time-value">
                  {todayAttendance?.checkOut ? formatTime(todayAttendance.checkOut) : '--:--'}
                </span>
              </div>
            </div>
            
            {todayAttendance?.workingHours && (
              <div className="time-card">
                <FaClock className="time-icon" />
                <div>
                  <span className="time-label">Working Hours</span>
                  <span className="time-value">
                    {todayAttendance.workingHours}
                  </span>
                </div>
              </div>
            )}
          </div>
          
          <div className="attendance-actions">
            <button 
              className={`action-button checkin-btn ${!canCheckIn() ? 'disabled' : ''}`}
              onClick={handleCheckIn}
              disabled={!canCheckIn() || isLoading}
            >
              {isLoading ? 'Processing...' : 'Check In'}
            </button>
            
            <button 
              className={`action-button checkout-btn ${!canCheckOut() ? 'disabled' : ''}`}
              onClick={handleCheckOut}
              disabled={!canCheckOut() || isLoading}
            >
              {isLoading ? 'Processing...' : 'Check Out'}
            </button>
          </div>
        </div>
        
        {/* Stats Cards */}
        <div className="stats-container">
          <div className="stat-card">
            <h3>This Month</h3>
            <div className="stat-value-large">
              {attendance.filter(a => 
                new Date(a.date).getMonth() === new Date().getMonth() && 
                a.status === 'present'
              ).length}
              <span>days</span>
            </div>
          </div>
          
          <div className="stat-card">
            <h3>Total Present</h3>
            <div className="stat-value-large">
              {attendance.filter(a => a.status === 'present').length}
              <span>days</span>
            </div>
          </div>
          
          <div className="stat-card">
            <h3>Attendance Rate</h3>
            <div className="stat-value-large">
              {calculatePercentage()}%
            </div>
          </div>
        </div>
        
        {/* Recent Attendance */}
        <div className="recent-attendance">
          <h2>Recent Attendance</h2>
          <div className="attendance-table">
            <div className="table-header">
              <span>Date</span>
              <span>Status</span>
              <span>Check In</span>
              <span>Check Out</span>
              <span>Hours</span>
            </div>
            
            {attendance.slice(0, 5).map((record) => (
              <div className="table-row" key={record.id}>
                <span>{formatDate(record.date)}</span>
                <span className={`status-badge ${record.status}`}>
                  {record.status}
                </span>
                <span>{formatTime(record.checkIn)}</span>
                <span>{formatTime(record.checkOut)}</span>
                <span>{record.workingHours || '--'}</span>
              </div>
            ))}
            
            {attendance.length === 0 && (
              <div className="table-empty">
                No attendance records found
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployeeDashboard;