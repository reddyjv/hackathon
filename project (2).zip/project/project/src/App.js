import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import EmployeeLogin from './components/EmployeeLogin';
import EmployeeRegister from './components/EmployeeRegister';
import AdminDashboard from './components/AdminDashboard';
import EmployeeDashboard from './components/EmployeeDashboard';


function App() {
  return (
    <Router>
      <div className="app">
        <Routes>
          <Route path="/" element={<EmployeeLogin />} />
          <Route path="/login" element={<EmployeeLogin />} />
          <Route path="/register" element={<EmployeeRegister />} />
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="/dashboard" element={<EmployeeDashboard />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;